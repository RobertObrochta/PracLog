<?php

if (isset($_POST["submit"])) {
  // $date = $_POST["date"] *This will eventually get the date from the log.html, and will be entered below in the $subject variable.
  $subject = "Today's Practice Log";
  $mailFrom = "praclog.com";
  $hours = $_POST["hours"];
  $progress = $_POST["progress"];
  $focus = $_POST["focus"];
  $efficient = $_POST["efficient"];
  $goals = $_POST["goals"];
  $key = $_POST["key"];

  $mailTo = $_POST["email"];
  $headers = "From: ".$mailFrom;
  $text = "Here is today's practice log. Great work!"."\n\n".$hours."\n\n".$progress."\n\n".$focus."\n\n".$efficient."\n\n".$goals."\n\n".$key;

  mail($mailTo, $subject, $text, $headers);
  header("Location: seeyou.html?mailsend");
}

?>